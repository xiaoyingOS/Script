双击运行00_Hash.bat即可，根据提示选择

Double click to run 00_ Hash.bat is sufficient, select according to the prompts