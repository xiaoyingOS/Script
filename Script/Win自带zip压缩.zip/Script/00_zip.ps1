﻿# 获取当前脚本所在的文件夹路径
$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Path

# 设置要压缩的文件夹路径为当前脚本所在的文件夹
$folderPath = $scriptFolder

# 定义目标文件夹名称
$destinationFolderName = "Folder"

# 构建目标文件夹路径
$destinationFolderPath = Join-Path -Path $folderPath -ChildPath $destinationFolderName

# 如果目标文件夹不存在，则创建它
if (-not (Test-Path -Path $destinationFolderPath -PathType Container)) {
    New-Item -ItemType Directory -Path $destinationFolderPath | Out-Null
}

# 获取要压缩的文件列表
$fileList = Get-ChildItem -Path $folderPath -File

# 遍历每个文件并压缩为对应的压缩文件
foreach ($file in $fileList) {
    # 构建压缩包路径和名称，使用文件名作为基础并添加 .zip 扩展名
    $zipPath = Join-Path -Path $destinationFolderPath -ChildPath "$($file.BaseName).zip"

    # 检查如果是指定的脚本或批处理文件，则跳过压缩
    $excludedFiles = @("00_run.bat", "00_zip.ps1", "01_run.bat", "01_7z.ps1", "03_run.bat", "03_WinRAR.ps1")

    if ($excludedFiles -contains $file.Name) {
        Write-Host "Skipping $($file.Name)..."
        continue
    }

    # 使用 Compress-Archive cmdlet 进行压缩
    Compress-Archive -Path $file.FullName -DestinationPath $zipPath
}

Write-Host "压缩完成 Done"

# 等待用户按下任意键，保持窗口打开
Write-Host "按下任意键关闭窗口 " -NoNewline
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
Write-Host ""