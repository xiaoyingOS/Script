English: Instructions for use: Select according to the prompts and provide the keywords to be removed from the file name
使用说明：根据提示选择，提供文件名中要去除的关键字。


English: Instructions for use: The program will replace all keywords with empty ones, renaming the file name after removing the keywords
使用说明：程序会把所有关键字替换为空，即重命名 去除关键字后的 文件名