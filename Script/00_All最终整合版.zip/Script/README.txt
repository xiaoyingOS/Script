1.双击运行00_All.bat文件即可，根据提示选择压缩模式和Hash自动计算模式，cmd命令效率不是很高，可以把它转为PowerShell文件

2.00_Hash.ps1文件【非必须，最好下载】计算效率比较快，所有生成的文件都在 当前目录的Folder文件夹中，【同名文件压缩进同一个压缩包】

3.不压缩同后缀名的文件【比如当前文件叫Hash.7z，选择7z后缀名压缩文件，会自动避开不压缩】压缩后，看看控制台有没有输出什么错误，检查一下文件个数


English：
1. Double click to run 00_ All. bat file is sufficient. Choose compression mode and hash automatic calculation mode according to the prompts. The cmd command is not very efficient, so it can be converted to a PowerShell file


2.00_ Hash.ps1 file [not mandatory, preferably downloaded] has a relatively fast computational efficiency, and all generated files are in the Folder folder of the current directory. [Files with the same name are compressed into the same compressed file]


3. Do not compress files with the same suffix (for example, if the current file is called Hash.7z, selecting the 7z suffix to compress the file will automatically avoid non compression). After compression, check if the console outputs any errors and check the number of files