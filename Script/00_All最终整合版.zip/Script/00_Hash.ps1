﻿# PowerShell 脚本开始
# PowerShell 脚本中添加 UTF-8 编码的注释
#encoding UTF-8
# 设置 CMD 窗口字符编码为 UTF-8
chcp 65001 | Out-Null

$filesCount = $args[0]
# 将用户输入和比较值都转换为小写
$filesCount = $filesCount.ToLower()

if($filesCount -eq 'y' -or $filesCount -eq ''){
    $totalFiles = @(Get-ChildItem -Path $targetDirectory -File -Recurse | Where-Object { $_.Name -ne "00_Hash.bat" -and $_.Name -ne "00_Hash.ps1" }).Count
} else {
    $totalFiles = @(Get-ChildItem -Path $targetDirectory -File | Where-Object { $_.Name -ne "00_Hash.bat" -and $_.Name -ne "00_Hash.ps1" }).Count
}

# 定义显示动态进度条的函数
function Show-RainbowProgressBar {
    param (
        [int]$Percentage
    )

    $barLength = 69
    $progressCount = [math]::Round(($Percentage * $barLength) / 100)

    # $colors = @("Red", "Yellow", "Green", "Cyan", "Blue", "Magenta")
    $colors = @("DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "Gray",
            "DarkGray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White")

    $progress = ""
    $colorIndex = 0

    # 如果百分比与上一次相同，则不输出
    if ($Percentage -ne $global:lastPercentage) {
    1..$barLength | ForEach-Object {
        if ($_ -le $progressCount) {
            $char = "▄"
            $color = $colors[$colorIndex]
            $colorIndex = ($colorIndex + 1) % $colors.Count
        } else {
            $char = "→"
            # $color = "White"
            $color = $colors[$colorIndex]
            $colorIndex = ($colorIndex + 1) % $colors.Count
        }
        $progressOutput += Write-Host -NoNewline -ForegroundColor $color $char
        # Start-Sleep -Milliseconds 0  # 调整速度

        if ($_ -eq $barLength) {
            $progressOutput += Write-Host -NoNewline -ForegroundColor "White" " [$Percentage%] "
            Write-Host ""
        }
    }
    # 更新上一次的百分比
        $global:lastPercentage = $Percentage
    }
    $progressOutput
}

$targetDirectory = $PWD.Path
$outputFilePath = Join-Path -Path $targetDirectory -ChildPath "Folder\00_HASH.txt"

# 检查输出文件目录是否存在，如果不存在则创建它
$outputDirectory = Split-Path -Path $outputFilePath -Parent
if (-not (Test-Path -Path $outputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $outputDirectory | Out-Null
    Write-Host "文件夹已创建成功: $outputDirectory 目录用来存放00_HASH.txt文件"
}

# 获取当前脚本所在的目录，包含后缀名
$currentDirectory = $PSScriptRoot

# 定义计算哈希值的函数
function Calculate-Hash {
    param (
        [string]$filePath
    )

    $hashAlgorithms = @("MD5", "SHA1", "SHA256", "SHA512")

    $result = @()

    foreach ($algorithm in $hashAlgorithms) {
        $hashValue = (Get-FileHash -Path $filePath -Algorithm $algorithm).Hash
        $result += "{0}: {1}" -f $algorithm, $hashValue
    }

    $result
}

# Write-Host "是否计算 子文件夹中的文件Hash值: (Y/N) [是的话：直接回车即可]"
# $recurse = Read-Host "Do you want to recurse into subdirectories? (Y/N)"
$recurse = $args[0]
# 将用户输入和比较值都转换为小写
$recurse = $recurse.ToLower()

Write-Host "--> Hash值正在计算中 Doing..."

# 遍历目标目录下的文件并计算哈希值
# 开始计时
$startTime = Get-Date
if ($recurse -eq 'y' -or $recurse -eq '') {
$results = Get-ChildItem -Path $targetDirectory -File -Recurse | Where-Object { $_.Name -ne "00_Hash.bat" -and $_.Name -ne "00_Hash.ps1" } |
    ForEach-Object {
    $filePath = $_.FullName
    $fileName = $_.Name
    
    $hashResults = Calculate-Hash -filePath $filePath
    ($hashResults | ForEach-Object { "{0} --> {1}" -f $fileName, $_ }) + "`r`n"  # 在每个文件的哈希结果之后添加两行空行

    # 增加索引
    $index++
    # 计算进度百分比并展示动态进度条
    $progressPercentage = [math]::Round(($index / $totalFiles) * 100)
    Show-RainbowProgressBar -Percentage $progressPercentage
    }
    
} else {
    $results = Get-ChildItem -Path $targetDirectory -File | Where-Object { $_.Name -ne "00_Hash.bat" -and $_.Name -ne "00_Hash.ps1" } |
        ForEach-Object {
        $filePath = $_.FullName
        $fileName = $_.Name
        $hashResults = Calculate-Hash -filePath $filePath
        ($hashResults | ForEach-Object { "{0} --> {1}" -f $fileName, $_ }) + "`r`n" # 在每个文件的哈希结果之后添加两行空行

        # 增加索引
        $index++
        # 计算进度百分比并展示动态进度条
        $progressPercentage = [math]::Round(($index / $totalFiles) * 100)
        Show-RainbowProgressBar -Percentage $progressPercentage
    }
}


# 将结果写入文件
$results | Out-File -FilePath $outputFilePath -Encoding utf8 -Append

# 结束计时
$endTime = Get-Date
$elapsedTime = $endTime - $startTime

Write-Host "`n"
Write-Host "--> 计算Hash值耗时: $($elapsedTime.Hours)小时: $($elapsedTime.Minutes)分钟: $($elapsedTime.Seconds)秒: $($elapsedTime.Milliseconds)毫秒"

Write-Host "--> Hash值已计算完成 Done..."
Write-Host "--> 00_HASH.txt文件已保存到: $outputFilePath"
# Write-Host "`n"

#使用7z计算哈希值
# 获取当前脚本所在的目录

# 等待用户按下任意键，保持窗口打开
Write-Host "按下任意键关闭窗口 Press any key to continue . . ." -NoNewline
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
Write-Host ""
# PowerShell 脚本结束
