﻿# 获取当前脚本所在的文件夹路径
$scriptFolder = Split-Path -Parent $MyInvocation.MyCommand.Path

# 设置要压缩的文件夹路径为当前脚本所在的文件夹
$folderPath = $scriptFolder

# 提示用户输入压缩格式
$compressionFormat = Read-Host "请输入压缩格式 (例如：rar 7z zip ...)"

# 获取WinRAR安装路径
$winrarPath = Read-Host "请输入WinRAR安装路径 (例如：C:\Program Files\WinRAR 例如：D:\WinRAR ...)"

# 指定保存压缩文件的文件夹路径
$destinationFolder = ".\Folder"

# 如果目标文件夹不存在，则创建它
if (-not (Test-Path -Path $destinationFolder -PathType Container)) {
    New-Item -Path $destinationFolder -ItemType Directory -Force
}

# 获取要压缩的文件列表
$fileList = Get-ChildItem -Path $folderPath -File

# 遍历每个文件并压缩为对应的压缩文件
foreach ($file in $fileList) {
    # 构建压缩包路径和名称，使用文件名作为基础并添加指定的压缩格式扩展名
    $compressedFilePath = Join-Path -Path $destinationFolder -ChildPath "$($file.BaseName).$compressionFormat"

    # 检查如果是指定的脚本或批处理文件，则跳过压缩
    $excludedFiles = @("00_run.bat", "00_zip.ps1", "01_run.bat", "01_7z.ps1", "03_run.bat", "03_WinRAR.ps1")

    if ($excludedFiles -contains $file.Name) {
        Write-Host "Skipping $($file.Name)..."
        continue
    }

    # 使用 WinRAR 命令行进行压缩
    & "$winrarPath\rar.exe" a -ep1 $compressedFilePath $file.FullName
}

Write-Host "压缩完成 Done"

# 等待用户按下任意键，保持窗口打开
Write-Host "按下任意键关闭窗口 " -NoNewline
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
Write-Host ""